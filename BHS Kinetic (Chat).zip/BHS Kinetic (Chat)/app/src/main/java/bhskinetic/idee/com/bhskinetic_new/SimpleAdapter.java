package bhskinetic.idee.com.bhskinetic_new;

public class SimpleAdapter {
}
