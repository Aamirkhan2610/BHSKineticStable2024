package bhskinetic.idee.com.bhskinetic_new;

import android.content.Context;
import android.util.AttributeSet;
import android.view.SurfaceView;

/**
 * Created by Admin on 7/6/2018.
 */

public class MySurfaceViewWithoutSignature extends SurfaceView {
    public MySurfaceViewWithoutSignature(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}