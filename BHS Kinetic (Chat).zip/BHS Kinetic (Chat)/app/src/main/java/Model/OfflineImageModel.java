package Model;

public class OfflineImageModel {

    public String getStr_iMeiNo() {
        return Str_iMeiNo;
    }

    public void setStr_iMeiNo(String str_iMeiNo) {
        Str_iMeiNo = str_iMeiNo;
    }

    public String getStr_Model() {
        return Str_Model;
    }

    public void setStr_Model(String str_Model) {
        Str_Model = str_Model;
    }

    public String getStr_ID() {
        return Str_ID;
    }

    public void setStr_ID(String str_ID) {
        Str_ID = str_ID;
    }

    public String getStr_Lat() {
        return Str_Lat;
    }

    public void setStr_Lat(String str_Lat) {
        Str_Lat = str_Lat;
    }

    public String getStr_Long() {
        return Str_Long;
    }

    public void setStr_Long(String str_Long) {
        Str_Long = str_Long;
    }

    public String getStr_Loc() {
        return Str_Loc;
    }

    public void setStr_Loc(String str_Loc) {
        Str_Loc = str_Loc;
    }

    public String getStr_GPS() {
        return Str_GPS;
    }

    public void setStr_GPS(String str_GPS) {
        Str_GPS = str_GPS;
    }

    public String getStr_DriverID() {
        return Str_DriverID;
    }

    public void setStr_DriverID(String str_DriverID) {
        Str_DriverID = str_DriverID;
    }

    public String getStr_JobView() {
        return Str_JobView;
    }

    public void setStr_JobView(String str_JobView) {
        Str_JobView = str_JobView;
    }

    public String getStr_TripNo() {
        return Str_TripNo;
    }

    public void setStr_TripNo(String str_TripNo) {
        Str_TripNo = str_TripNo;
    }

    public String getRemarks() {
        return Remarks;
    }

    public void setRemarks(String remarks) {
        Remarks = remarks;
    }

    public String getStr_JobNo() {
        return Str_JobNo;
    }

    public void setStr_JobNo(String str_JobNo) {
        Str_JobNo = str_JobNo;
    }

    public String getRev_Name() {
        return Rev_Name;
    }

    public void setRev_Name(String rev_Name) {
        Rev_Name = rev_Name;
    }

    public String getStr_Nric() {
        return Str_Nric;
    }

    public void setStr_Nric(String str_Nric) {
        Str_Nric = str_Nric;
    }

    public String getStr_Sts() {
        return Str_Sts;
    }

    public void setStr_Sts(String str_Sts) {
        Str_Sts = str_Sts;
    }

    public String getStr_JobExe() {
        return Str_JobExe;
    }

    public void setStr_JobExe(String str_JobExe) {
        Str_JobExe = str_JobExe;
    }

    public String getFilename() {
        return Filename;
    }

    public void setFilename(String filename) {
        Filename = filename;
    }

    public String getfType() {
        return fType;
    }

    public void setfType(String fType) {
        this.fType = fType;
    }



    public void setIMG_URI(String IMG_URI) {
        this.IMG_URI = IMG_URI;
    }

    public String getIMG_URI() {
        return IMG_URI;
    }

    private String IMG_URI="";
    private String Str_iMeiNo="";
    private String Str_Model="";
    private String Str_ID="";
    private String Str_Lat="";
    private String Str_Long="";
    private String Str_Loc="";
    private String Str_GPS="";
    private String Str_DriverID="";
    private String Str_JobView="";
    private String Str_TripNo="";
    private String Remarks="";
    private String Str_JobNo="";
    private String Rev_Name="";
    private String Str_Nric="";
    private String Str_Sts="";
    private String Str_JobExe="";
    private String Filename="";
    private String fType="";

}
