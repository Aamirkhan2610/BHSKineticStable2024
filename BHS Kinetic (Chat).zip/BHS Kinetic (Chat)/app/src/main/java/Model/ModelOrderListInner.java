package Model;

/**
 * Created by Aamir on 4/16/2017.
 */

public class ModelOrderListInner {

    private String Attch="";
    private String Button="";
    private String Delivery_Loc="";
    private String JobNo ="";
    private String name="";
    private String Ord_Type ="";
    private String qty="";
    private String status ="";

    public String getJobFor() {
        return JobFor;
    }

    public void setJobFor(String jobFor) {
        JobFor = jobFor;
    }

    private String JobFor="";
    private String vContact_No="";
    private String vDlvry_Dt="";

    public String getvAdd_Info () {
        return vAdd_Info;
    }

    public void setvAdd_Info(String vAdd_Info) {
        this.vAdd_Info = vAdd_Info;
    }

    private String vAdd_Info="";

    public String getvTrip_Tm() {
        return vTrip_Tm;
    }

    public void setvTrip_Tm(String vTrip_Tm) {
        this.vTrip_Tm = vTrip_Tm;
    }

    private String vTrip_Tm="";
    private String vLat="";
    private String vLon="";
    private String vGPS="";

    public String getvGPS() {
        return vGPS;
    }

    public void setvGPS(String vGPS) {
        this.vGPS = vGPS;
    }

    public String getpLat() {
        return pLat;
    }

    public void setpLat(String pLat) {
        this.pLat = pLat;
    }

    public String getpLon() {
        return pLon;
    }

    public void setpLon(String pLon) {
        this.pLon = pLon;
    }

    public String getdLat() {
        return dLat;
    }

    public void setdLat(String dLat) {
        this.dLat = dLat;
    }

    public String getdLon() {
        return dLon;
    }

    public void setdLon(String dLon) {
        this.dLon = dLon;
    }

    private String pLat="";
    private String pLon="";

    private String dLat="";
    private String dLon="";

    private String vRmks="";
    private String Trip_Cost="0";
    private String Other_Cost ="0";

    public String getTrip_Cost() {
        return Trip_Cost;
    }

    public void setTrip_Cost(String trip_Cost) {
        Trip_Cost = trip_Cost;
    }

    public String getOther_Cost() {
        return Other_Cost;
    }

    public void setOther_Cost(String other_Cost) {
        Other_Cost = other_Cost;
    }

    public String getAttch() {
        return Attch;
    }

    public void setAttch(String attch) {
        Attch = attch;
    }

    public String getButton() {
        return Button;
    }

    public void setButton(String button) {
        Button = button;
    }

    public String getDelivery_Loc() {
        return Delivery_Loc;
    }

    public void setDelivery_Loc(String delivery_Loc) {
        Delivery_Loc = delivery_Loc;
    }

    public String getJobNo() {
        return JobNo;
    }

    public void setJobNo(String jobNo) {
        JobNo = jobNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrd_Type() {
        return Ord_Type;
    }

    public void setOrd_Type(String ord_Type) {
        Ord_Type = ord_Type;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getvContact_No() {
        return vContact_No;
    }

    public void setvContact_No(String vContact_No) {
        this.vContact_No = vContact_No;
    }

    public String getvDlvry_Dt() {
        return vDlvry_Dt;
    }

    public void setvDlvry_Dt(String vDlvry_Dt) {
        this.vDlvry_Dt = vDlvry_Dt;
    }

    public String getvLat() {
        return vLat;
    }

    public void setvLat(String vLat) {
        this.vLat = vLat;
    }

    public String getvLon() {
        return vLon;
    }

    public void setvLon(String vLon) {
        this.vLon = vLon;
    }

    public String getvRmks() {
        return vRmks;
    }

    public void setvRmks(String vRmks) {
        this.vRmks = vRmks;
    }
}
