package Model;

public class ModelBHSNews {
    public String getSeqNo() {
        return SeqNo;
    }

    public void setSeqNo(String seqNo) {
        SeqNo = seqNo;
    }

    public String getRemarks() {
        return Remarks;
    }

    public void setRemarks(String remarks) {
        Remarks = remarks;
    }

    public String getNft_Dt() {
        return Nft_Dt;
    }

    public void setNft_Dt(String nft_Dt) {
        Nft_Dt = nft_Dt;
    }

    public String getLike() {
        return like;
    }

    public void setLike(String like) {
        this.like = like;
    }

    public String getUnlike() {
        return unlike;
    }

    public void setUnlike(String unlike) {
        this.unlike = unlike;
    }

    public String getSmile() {
        return smile;
    }

    public void setSmile(String smile) {
        this.smile = smile;
    }

    public String getStar() {
        return star;
    }

    public void setStar(String star) {
        this.star = star;
    }

    public String getLove() {
        return Love;
    }

    public void setLove(String love) {
        Love = love;
    }

    public String getHappy() {
        return happy;
    }

    public void setHappy(String happy) {
        this.happy = happy;
    }

    public String getAngry() {
        return angry;
    }

    public void setAngry(String angry) {
        this.angry = angry;
    }

    public String getBored() {
        return bored;
    }

    public void setBored(String bored) {
        this.bored = bored;
    }

    public String getPuzzled() {
        return puzzled;
    }

    public void setPuzzled(String puzzled) {
        this.puzzled = puzzled;
    }

    public String getSurprised() {
        return surprised;
    }

    public void setSurprised(String surprised) {
        this.surprised = surprised;
    }

    String SeqNo="";
    String Remarks="";
    String Nft_Dt="";
    String like="";
    String unlike="";
    String smile="";
    String star="";
    String Love="";
    String happy="";
    String angry="";
    String bored="";
    String puzzled="";
    String surprised="";
}
