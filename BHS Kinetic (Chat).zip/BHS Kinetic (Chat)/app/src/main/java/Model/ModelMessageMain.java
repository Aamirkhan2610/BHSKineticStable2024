package Model;

/**
 * Created by Aamir on 5/22/2017.
 */


public class ModelMessageMain {

    private String Str_MsgID="";
    private String Str_CreatedBy="";

    public String getStr_MsgID() {
        return Str_MsgID;
    }

    public void setStr_MsgID(String str_MsgID) {
        Str_MsgID = str_MsgID;
    }

    public String getStr_CreatedBy() {
        return Str_CreatedBy;
    }

    public void setStr_CreatedBy(String str_CreatedBy) {
        Str_CreatedBy = str_CreatedBy;
    }

    public String getStr_SentTo() {
        return Str_SentTo;
    }

    public void setStr_SentTo(String str_SentTo) {
        Str_SentTo = str_SentTo;
    }

    public String getStr_Message() {
        return Str_Message;
    }

    public void setStr_Message(String str_Message) {
        Str_Message = str_Message;
    }

    public String getStr_Msd_Dt() {
        return Str_Msd_Dt;
    }

    public void setStr_Msd_Dt(String str_Msd_Dt) {
        Str_Msd_Dt = str_Msd_Dt;
    }

    public String getStr_Read_Sts() {
        return Str_Read_Sts;
    }

    public void setStr_Read_Sts(String str_Read_Sts) {
        Str_Read_Sts = str_Read_Sts;
    }

    public String getStr_Read_At() {
        return Str_Read_At;
    }

    public void setStr_Read_At(String str_Read_At) {
        Str_Read_At = str_Read_At;
    }

    private String Str_SentTo="";
    private String Str_Message="";
    private String Str_Msd_Dt="";
    private String Str_Read_Sts="";
    private String Str_Read_At="";
    private String Str_Trip_No="";

    public String getStr_Trip_No() {
        return Str_Trip_No;
    }

    public void setStr_Trip_No(String str_Trip_No) {
        Str_Trip_No = str_Trip_No;
    }

    public String getStr_Job_No() {
        return Str_Job_No;
    }

    public void setStr_Job_No(String str_Job_No) {
        Str_Job_No = str_Job_No;
    }

    private String Str_Job_No="";
}
