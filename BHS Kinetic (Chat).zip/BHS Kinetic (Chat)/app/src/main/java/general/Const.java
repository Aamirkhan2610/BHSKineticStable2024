package general;


import java.util.ArrayList;

public class Const {
	public static final ArrayList<offerObject> offerlist = new ArrayList<offerObject>();
}
